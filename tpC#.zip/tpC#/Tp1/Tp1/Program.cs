﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, C;
            System.Console.WriteLine("entre premier entier");
            a = int.Parse(System.Console.ReadLine());
            //System.Console.ReadKey();
            System.Console.WriteLine("entre deuxiem entier");
            b= int.Parse(System.Console.ReadLine());
           // System.Console.ReadKey();
          C = a + b;
        
            System.Console.WriteLine("la somme est " + C);
            System.Console.ReadKey();
        }
    }
}
