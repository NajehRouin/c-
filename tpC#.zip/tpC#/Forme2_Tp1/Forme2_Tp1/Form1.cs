﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forme2_Tp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton1.Checked == true)
            {
                String res1 = "boutton radio 1  ";
                String res2 = "boutton radio 2 ";
                String res3 = "boutton radio 3  ";
                this.listBox1.Items.Add(res1 + this.radioButton1.Checked);
                this.listBox1.Items.Add(res2 + this.radioButton2.Checked);
                this.listBox1.Items.Add(res3 + this.radioButton3.Checked);
            }
            else
            {
                this.listBox1.Items.Clear();
            }

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton2.Checked == true)
            {
                String res1 = "boutton radio 1  ";

                String res2 = "boutton radio 2  ";
                String res3 = "boutton radio 3 ";
                this.listBox1.Items.Add(res1 + this.radioButton1.Checked);
                this.listBox1.Items.Add(res2 + this.radioButton2.Checked);
                this.listBox1.Items.Add(res3 + this.radioButton3.Checked);
            }
            else
            {
                this.listBox1.Items.Clear();
            }

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton3.Checked == true)
            {
                String res1 = "boutton radio 1 = ";
                String res2 = "boutton radio 2 = ";
                String res3 = "boutton radio 3 = ";
                this.listBox1.Items.Add(res1 + this.radioButton1.Checked);
                this.listBox1.Items.Add(res2 + this.radioButton2.Checked);
                this.listBox1.Items.Add(res3 + this.radioButton3.Checked );
                
            }
            else
            {
                this.listBox1.Items.Clear();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1.Checked)
            {
                this.listBox1.Items.Add("checkbox1 " + this.checkBox1.Checked);
                
            }
            else
            {
                this.listBox1.Items.Clear();
            }

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {
           
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox2.Checked)
            {
               
                this.listBox1.Items.Add("checkbox2" + this.checkBox2.Checked);

            }
            else
            {
                this.listBox1.Items.Clear();
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox3.Checked)
            {
               
                this.listBox1.Items.Add("checkbox3" + this.checkBox3.Checked);
            }
            else
            {
                this.listBox1.Items.Clear();
            }

        }
    }
}