﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Calcul
{
    class Program
    {
        static void Main(string[] args)
        {
            int val1, val2,val3;
            String op ;
            val1 = int.Parse(System.Console.ReadLine());
           op= System.Console.ReadLine();
           if (op == "+") { 
               val2 = int.Parse(System.Console.ReadLine());
               val3 = val1 + val2;
               System.Console.WriteLine("la somme est " + val3);
               System.Console.ReadKey();

           }
           if (op == "-")
           {
               val2 = int.Parse(System.Console.ReadLine());
               val3 = val1 - val2;
               System.Console.WriteLine("la soustraction est " + val3);
               System.Console.ReadKey();

           }
           if (op == "*")
           {
               val2 = int.Parse(System.Console.ReadLine());
               val3 = val1 * val2;
               System.Console.WriteLine("le produit est " + val3);
               System.Console.ReadKey();

           }
           if (op == "/")
           {
               val2 = int.Parse(System.Console.ReadLine());
               if (val2 == 0) { System.Console.WriteLine("erreur"); }
               else
               {
                   val3 = val1 / val2;
                   System.Console.WriteLine("la division est " + val3);
                   System.Console.ReadKey();
               }

           }

          

        }
    }
}
