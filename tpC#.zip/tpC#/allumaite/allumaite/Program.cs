﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace allumaite
{
    class Program
    {
        static void Main(string[] args)
        {
            int nballumette = 21;
            
            int nbcasj1, nbcasj2;
           
            String nomj1, nomj2;
            System.Console.WriteLine("Bienvenue ");
            System.Console.WriteLine(" saisier votre nome svp vous avez 1 joueur");
            nomj1 = System.Console.ReadLine();
           
            System.Console.WriteLine(" saisier votre nome svp vous avez la 2 joueur");
            nomj2 = System.Console.ReadLine();
           
            while (nballumette > 0)
            {
                
                    do
                    {


                        System.Console.WriteLine("salut  " + nomj1 + "  choisissez svp allumette entre 1 et 3");
                        nbcasj1 = int.Parse(System.Console.ReadLine());
                       




                    } while ((nbcasj1 < 1) || (nbcasj1 > 3));
                    nballumette = nballumette - nbcasj1;
                    System.Console.WriteLine("la reste du allumette est " + nballumette);
                   
                if (nballumette == 0)
                {
                    System.Console.WriteLine("desole " + nomj1 + " tu es perdu");}

                
               

                do
                {
                  

                    System.Console.WriteLine("salut  " + nomj2 + "  choisissez svp allumette entre 1 et 3");
                    nbcasj2 = int.Parse(System.Console.ReadLine());
                    

                   

                } while ((nbcasj2 < 1) || (nbcasj2 > 3));
                nballumette = nballumette - nbcasj2;
                System.Console.WriteLine("la reste du allumette est " + nballumette);
                
                  if (nballumette == 0) { 
                        System.Console.WriteLine("desole " + nomj2 + " tu es perdu"); 

                    }
                }
               
            }
            
        }
    }

